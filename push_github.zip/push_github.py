# import subprocess

# # Replace these with your actual Git commands
# git_commands = [
#     "git init",
#     "git remote rm origin"
#     "git add piprojections-2b9819f2c3b2.json",
#     "git commit -m 'Initial commit' ",
#     "git remote add origin https://github.com/saisrivenkat/piexample.git",
#     "git branch -M main",
#     "git push -u origin main",
# ]

# # Run Git commands
# for command in git_commands:
#     result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
#     # Check if the command was successful
#     if result.returncode == 0:
#         print(f"Command succeeded: {command}")
#     else:
#         print(f"Command failed: {command}")
#         print("Error output:")
#         print(result.stderr)

# import requests
# import subprocess

# # Replace with your GitHub username and personal access token
# github_token = "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"

# # Repository owner (the other user's GitHub username) and repository name
# repository_owner = "saisrivenkat"
# repository_name = "piexample143"
# repository_description = "Description for the new repository"
# repository_private = False  # Set to True if you want a private repository

# # Create a new repository on GitHub
# url = f"https://api.github.com/user/repos"
# headers = {
#     "Authorization": f"token {github_token}",
#     "Accept": "application/vnd.github.v3+json"
# }
# data = {
#     "name": repository_name,
#     "description": repository_description,
#     "private": repository_private
# }

# response = requests.post(url, headers=headers, json=data)

# if response.status_code == 201:
#     print("Repository created successfully on GitHub.")
# else:
#     print(f"Failed to create the repository. Status code: {response.status_code}")
#     print(response.text)

# # Initialize a local Git repository
# subprocess.run(["git", "init"])

# # Add and commit your files to the local repository
# subprocess.run(["git", "add", "."])
# subprocess.run(["git", "commit", "-m", "Initial commit"])

# # Add the GitHub repository as a remote
# subprocess.run(["git", "remote", "add", "origin", f"https://github.com/{repository_owner}/{repository_name}.git"])

# # Push the local repository to GitHub
# subprocess.run(["git", "push", "-u", "origin", "master"])

# import requests
# import subprocess
# import shutil

# # Replace with your own GitHub username and personal access token
# github_username = "YourUsername"
# github_token = "YourPersonalAccessToken"

# # Repository owner (the other user's GitHub username) and repository name
# repository_owner = "OtherUser"
# repository_name = "OtherUserRepo"

# # Local repository path
# local_repository_path = "/path/to/your/local/repo"

# # Clone the other user's repository to a temporary directory
# temp_directory = "/path/to/temporary/directory"
# temp_repository_path = f"{temp_directory}/{repository_name}"

# clone_command = f"git clone https://github.com/{repository_owner}/{repository_name}.git {temp_repository_path}"
# subprocess.run(clone_command, shell=True)

# # Copy the contents of your local repository to the cloned repository
# shutil.copytree(local_repository_path, temp_repository_path)

# # Commit and push the changes
# commit_command = f"cd {temp_repository_path} && git add . && git commit -m 'Push local repository' && git push origin main"
# subprocess.run(commit_command, shell=True)

# # Remove the temporary directory
# shutil.rmtree(temp_directory)

# print("Local repository pushed to the other user's GitHub repository.")

import requests
import base64
github_token = "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"

# Repository owner (the other user's GitHub username) and repository name
repo_owner = "saisrivenkat"
repo_name = "piexample143"

branch_name = 'main'
file_path = 'path/to/your/archive.zip'
access_token = 'YOUR_PERSONAL_ACCESS_TOKEN'

# Read the zip file as binary
with open(file_path, 'rb') as file:
    file_data = base64.b64encode(file.read()).decode('utf-8')

headers = {
    'Authorization': f'token {access_token}',
    'Content-Type': 'application/json',
}

# Create or update the zip file in the repository
commit_message = 'Add your commit message here'
file_content = {
    "message": commit_message,
    "content": file_data,
    "branch": branch_name
}

response = requests.put(
    f'https://api.github.com/repos/{repo_owner}/{repo_name}/contents/{file_path}',
    headers=headers,
    json=file_content
)

result = response.json()
print(result)
